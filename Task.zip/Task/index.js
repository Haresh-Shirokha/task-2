const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors'); 

const app = express();
const port = 8080;

const mongoURI = 'YOUR_MONGO_URI';

mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true });
const db = mongoose.connection;

db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');
});

const configurationSchema = new mongoose.Schema({
  _id: String,
  data: [[String]],
  remark: String,
});

// db.once('open', async () => {
//     console.log('Connected to MongoDB');
  
//     // Create a sample configuration for testing
//     const sampleConfig = new Configuration({
//       _id: 'qwertyuiop',
//       data: [['sym1', 'sym2', 'sym3'], ['sym4', 'sym6', 'sym8'], ['sym5', 'sym1', 'sym0']],
//       remark: 'Initial remark',
//     });
  
//     // Save the sample configuration to MongoDB
//     await sampleConfig.save();
  
//     console.log('Sample configuration created');
//   });

const Configuration = mongoose.model('Configuration', configurationSchema);

app.use(cors()); 
app.use(bodyParser.json());

app.get('/api/configurations/:id', async (req, res) => {
  try {
    const configId = req.params.id;
    const config = await Configuration.findById(configId);

    if (!config) {
      return res.status(404).json({ error: 'Configuration not found' });
    }

    res.json(config);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// app.put('/api/configurations/:id', async (req, res) => {
//   try {
//     const configId = req.params.id;
//     const remark = req.body.remark;

    
//     const config = await Configuration.findById(configId);

//     if (!config) {
//       return res.status(404).json({ error: 'Configuration not found' });
//     }

    
//     config.remark = remark;

    
//     await config.save();

//     res.json({ message: 'success' });
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ error: 'Internal Server Error' });
//   }
// });


app.put('/api/configurations/:id', async (req, res) => {
  try {
    const configId = req.params.id;
    const remark = req.body.remark;

    
    const config = await Configuration.findById(configId);

    if (!config) {
      return res.status(404).json({ error: 'Configuration not found' });
    }

    
    config.remark = remark;

    
    await config.save();

    
    const updatedConfig = await Configuration.findById(configId);

    res.json({ message: 'success', data: updatedConfig });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
