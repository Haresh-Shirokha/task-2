
async function updateConfiguration() {
    const configId = document.getElementById('configId').value;
    const remark = document.getElementById('remark').value;
  
    try {
      const response = await fetch(`http://localhost:8080/api/configurations/${configId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ remark }),
      });
  
      const result = await response.json();
  
      
      const resultDiv = document.getElementById('result');
      resultDiv.innerHTML = '';
  
      if (result.message === 'success' && result.data) {
        
        const idParagraph = document.createElement('p');
        idParagraph.textContent = `ID: ${result.data._id}`;
        resultDiv.appendChild(idParagraph);
  
        
        const dataParagraph = document.createElement('p');
      dataParagraph.textContent = `Data:`;
      resultDiv.appendChild(dataParagraph);
        const table = document.createElement('table');
        table.setAttribute('border', '1');
  
        result.data.data.forEach((rowData) => {
          const row = document.createElement('tr');
          rowData.forEach((cellData) => {
            const cell = document.createElement('td');
            cell.textContent = cellData;
            row.appendChild(cell);
          });
          table.appendChild(row);
        });
  
        resultDiv.appendChild(table);
  
        
        const remarkParagraph = document.createElement('p');
        remarkParagraph.textContent = `Updated Remark: ${result.data.remark}`;
        resultDiv.appendChild(remarkParagraph);
  
        resultDiv.style.display = 'block';
      } else {
        resultDiv.textContent = 'Error updating configuration';
        resultDiv.style.display = 'block';
      }
  
      alert(result.message);
    } catch (error) {
      console.error('Error updating configuration:', error.message);
      alert('Error updating configuration');
    }
  }
  